import React from "react";
import "./Styles/App.css";
import { LandingPage } from "./Pages/LandingPage";

const App: React.FC = () => {
  return <LandingPage />;
};
export default App;
